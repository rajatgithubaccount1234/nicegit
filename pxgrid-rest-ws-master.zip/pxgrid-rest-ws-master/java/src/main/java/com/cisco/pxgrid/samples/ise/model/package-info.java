/**
 * This is pxGrid data model for all pxGrid control communication
 * These can be used for XML or JSON
 */
@javax.xml.bind.annotation.XmlSchema(namespace="http://www.cisco.com/pxgrid")
package com.cisco.pxgrid.samples.ise.model;

