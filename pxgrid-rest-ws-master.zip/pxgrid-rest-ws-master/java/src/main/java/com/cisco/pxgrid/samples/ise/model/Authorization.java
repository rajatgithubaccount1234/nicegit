package com.cisco.pxgrid.samples.ise.model;

/**
 * @since 2.0
 */
public enum Authorization {
	PERMIT, DENY;
}
