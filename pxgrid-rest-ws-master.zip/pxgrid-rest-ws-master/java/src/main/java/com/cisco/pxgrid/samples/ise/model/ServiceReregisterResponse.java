package com.cisco.pxgrid.samples.ise.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * The response corresponding to ServiceReregisterRequest
 * 
 * @since 2.0
 */
@XmlRootElement
public class ServiceReregisterResponse {
}
