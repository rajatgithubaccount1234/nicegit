package com.cisco.pxgrid.samples.ise.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * The response corresponding to ServiceUnregisterRequest
 * 
 * @since 2.0
 */
@XmlRootElement
public class ServiceUnregisterResponse {
}
