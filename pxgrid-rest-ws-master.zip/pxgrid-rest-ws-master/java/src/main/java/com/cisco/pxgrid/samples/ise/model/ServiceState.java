package com.cisco.pxgrid.samples.ise.model;

/**
 * @since 2.0
 */
public enum ServiceState {
	ADDED, REMOVED, ENABLED, DISABLED;
}
